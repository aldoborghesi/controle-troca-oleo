export class Constants {
  public static readonly TROCAROLEO_KEY = 'trocas';

}
